package com.blc.beans;

import lombok.ToString;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@ToString
public class Calculator implements InitializingBean, DisposableBean {
    private int a;
    private int b;
    private int sum;

    public Calculator(@Value("${a}") int a) {
        this.a = a;
    }

    @Override
    public void destroy() throws Exception {
        this.a = 0;
        this.b = 0;
        this.sum = 0;
        System.out.println("destroy()");
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        System.out.println("afterPropertiesSet()");
        this.sum = this.a + this.b;
    }

    /**
     * after all the dependencies are injected, before placing the bean definition object
     * in ioc container, it invokes the @PostConstruct method on the bean object
     */
    /*@PostConstruct
    public void init() {
        System.out.println("init()");
        this.sum = this.a + this.b;
    }*/
    @Value("${b}")
    public void setB(int b) {
        this.b = b;
    }

    /**
     * before removing the bean definition object from the ioc container, the
     * ioc container invokes the @PreDestroy method to perform pre-destruction logic
     */
    /*@PreDestroy
    public void release() {
        a = 0;
        b = 0;
        sum = 0;
        System.out.println("release()");
    }*/
}

