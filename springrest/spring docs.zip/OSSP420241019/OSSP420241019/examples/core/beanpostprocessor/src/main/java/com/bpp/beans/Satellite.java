package com.bpp.beans;

import org.springframework.stereotype.Component;

@Component
public class Satellite {
    public Satellite() {
        System.out.println("Satellite()");
    }
}
