package com.lmi.beans;

import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.stereotype.Component;

@Component
public abstract class PropertyManager {

    public double estimate(String propertyType, int floors, String facing, int sqYards, String address) {
        double estimatedValue = 0.0;
        PropertyEstimator propertyEstimator = null;

        propertyEstimator = lookupPropertyEstimator();
        System.out.println("property estimator ref#:" + propertyEstimator.hashCode());
        propertyEstimator.setPropertyType(propertyType);
        propertyEstimator.setFacing(facing);
        propertyEstimator.setAddress(address);
        propertyEstimator.setFloors(floors);
        propertyEstimator.setSqYards(sqYards);
        estimatedValue = propertyEstimator.estimate();


        return estimatedValue;
    }

    @Lookup("propertyEstimator")
    abstract public PropertyEstimator lookupPropertyEstimator();
}
