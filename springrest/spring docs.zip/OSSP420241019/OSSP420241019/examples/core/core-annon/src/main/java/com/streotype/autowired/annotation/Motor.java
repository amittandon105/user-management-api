package com.streotype.autowired.annotation;

// no sourcecode
public class Motor {
    public void rotate() {
        System.out.printf("motor: rotating...");
    }
}
