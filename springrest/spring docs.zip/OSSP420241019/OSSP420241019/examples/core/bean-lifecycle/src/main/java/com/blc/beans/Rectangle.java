package com.blc.beans;

import lombok.ToString;

@ToString
public class Rectangle {
    private double length;
    private double breath;
    private double area;


    public void init() {
        System.out.println("initializing..");
        this.area = this.length * this.breath;
    }

    public Rectangle(double length) {
        this.length = length;
    }

    public void setBreath(double breath) {
        this.breath = breath;
    }

    public void terminate() {
        System.out.println("closing..");
        length = 0;
        breath = 0;
        area = 0;
    }
}
