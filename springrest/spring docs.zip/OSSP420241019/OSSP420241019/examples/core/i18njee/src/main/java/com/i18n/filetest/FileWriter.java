package com.i18n.filetest;

import java.io.*;


public class FileWriter {
    public static void main(String[] args) throws IOException {

        FileOutputStream fos = new FileOutputStream(new File("/Users/sriman/contents.txt"));
        BufferedOutputStream bos = new BufferedOutputStream(fos);
        StringBuffer buffer = new StringBuffer();
        buffer.append("शुभ प्रभात");
        bos.write(buffer.toString().getBytes());
        bos.close();
    }
}
