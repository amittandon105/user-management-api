package com.i18n.filetest;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;

public class FileWriterI18N {
    public static void main(String[] args) throws IOException {
        FileWriter fileWriter = new FileWriter("/Users/sriman/notes.txt",
                Charset.forName("UTF-8"));
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        bufferedWriter.write("शुभ प्रभात");
        bufferedWriter.close();
    }
}
