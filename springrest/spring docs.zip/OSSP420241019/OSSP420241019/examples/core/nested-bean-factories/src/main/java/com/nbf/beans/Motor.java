package com.nbf.beans;

import lombok.Setter;
import lombok.ToString;

@Setter
@ToString
public class Motor {
    private FuelTank fuelTank;

}
