package com.blc.test;

import com.blc.beans.Calculator;
import com.blc.beans.Rectangle;
import com.blc.config.BLCConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class BLCTest {
    public static void main(String[] args) {


        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(BLCConfig.class);
        ((ConfigurableApplicationContext) applicationContext).registerShutdownHook();

        //Runtime.getRuntime().addShutdownHook(new Thread(new ShutdownHook(applicationContext)));
        // register the shutdown hook thread to jvm asking him to inform when it is going to die

        /*Calculator cal = applicationContext.getBean(Calculator.class);
        System.out.println(cal);*/

        Rectangle rectangle = applicationContext.getBean(Rectangle.class);
        System.out.println(rectangle);

        // end of the application
        //((ConfigurableApplicationContext)applicationContext).close();
    }
}
