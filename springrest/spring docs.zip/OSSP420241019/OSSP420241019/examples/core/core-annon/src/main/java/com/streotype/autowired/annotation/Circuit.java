package com.streotype.autowired.annotation;

// no sourcecode
public class Circuit {
    public void on() {
        System.out.println("Circuit on");
    }
}
