package com.stereotype.javaconfig.autowire.annotation;

// no sourcecode
public class Motor {
    public void run() {
        System.out.println("running...");
    }
}
