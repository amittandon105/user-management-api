package com.javaconfig.stereotype.autowire.annotation;

public interface IReceiver {
    void receive(int frequency);
}
