package com.bpp.beans;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class Processor {
    public Processor() {
        System.out.println("processor()");
    }
}
