package com.ai.beans;

import org.springframework.stereotype.Component;

@Component
public class JioStandardSetTopBox implements SetTopBox {
    @Override
    public void on() {
        System.out.println("jio standard set-top box has been on...");
    }
}
