package com.fb.test;

import com.fb.beans.Reminder;
import com.fb.config.FBJavaConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class FBTest {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(FBJavaConfig.class);
        Reminder reminder = applicationContext.getBean(Reminder.class);
        System.out.println(reminder);
    }
}
