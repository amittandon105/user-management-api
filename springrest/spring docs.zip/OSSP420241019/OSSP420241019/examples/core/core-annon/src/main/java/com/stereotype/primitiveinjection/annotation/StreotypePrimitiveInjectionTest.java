package com.stereotype.primitiveinjection.annotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class StreotypePrimitiveInjectionTest {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext("com.stereotype.primitiveinjection.annotation");
        Book book = context.getBean(Book.class);
        System.out.println(book);
    }
}
