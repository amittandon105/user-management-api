package com.di.beans;

public class WeatherWidget {
    private IWeatherFinder weatherFinder;

    public WeatherWidget(IWeatherFinder weatherFinder) {
        System.out.println("WeatherFinder(IWeatherFinder)");
        this.weatherFinder = weatherFinder;
    }

    public void showWeather(String zipCode) {
        double temparature = 0.0;

        temparature = weatherFinder.getWeather(zipCode);
        System.out.println("temparature : " + temparature + " for the zipCode: " + zipCode);
    }

    /*public void setWeatherFinder(IWeatherFinder weatherFinder) {
        System.out.println("setWeatherFinder(weatherFinder)");
        this.weatherFinder = weatherFinder;
    }*/
}
