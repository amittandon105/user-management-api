package com.lmi.test;

import com.lmi.beans.PropertyManager;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class LMITest {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext("com.lmi.beans");
        PropertyManager propertyManager = applicationContext.getBean(PropertyManager.class);

        System.out.println("propertyManager classType:" + propertyManager.getClass().getName());


        double estimatedCost = propertyManager.estimate("2 story building",2, "east", 300, "10 Main Street, Chicago, US 47484");
        System.out.println("estimated cost : " + estimatedCost);

        estimatedCost = propertyManager.estimate("3 story building",3, "west", 500, "10 Main Street, Chicago, US 47484");
        System.out.println("estimated cost : " + estimatedCost);
    }
}
