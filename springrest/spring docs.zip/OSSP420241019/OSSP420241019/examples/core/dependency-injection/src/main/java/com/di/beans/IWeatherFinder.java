package com.di.beans;

public interface IWeatherFinder {
    double getWeather(String zipCode);
}
