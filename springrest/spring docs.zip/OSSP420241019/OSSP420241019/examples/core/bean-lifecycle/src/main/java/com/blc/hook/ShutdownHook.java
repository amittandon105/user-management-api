package com.blc.hook;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

public class ShutdownHook implements Runnable {
    private ApplicationContext applicationContext;

    public ShutdownHook(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    @Override
    public void run() {
        ((ConfigurableApplicationContext)applicationContext).close();
    }
}
