package com.sdp.test;

import com.sdp.beans.DigitalBoard;
import com.sdp.beans.IMessageConverter;
import com.sdp.beans.MessageWriter;
import com.sdp.helper.AppFactory;

import java.io.IOException;

public class SDPTest {
    public static void main(String[] args) throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        IMessageConverter htmlMessageConverter = (IMessageConverter) AppFactory.createObject("htmlMessageConverter");
        IMessageConverter pdfMessageConverter = (IMessageConverter) AppFactory.createObject("pdfMessageConverter");

        MessageWriter messageWriter = (MessageWriter) AppFactory.createObject("messageWriter");
        messageWriter.setMessageConverter(htmlMessageConverter);

        DigitalBoard digitalBoard = (DigitalBoard) AppFactory.createObject("digitalBoard");
        digitalBoard.setMessageConverter(pdfMessageConverter);

        messageWriter.writeMessage("Welcome to Strategy Design Pattern!");
        digitalBoard.on("Welcome to Strategy Pattern from DigitalBoard");
    }
}
