package com.javaconfig.annotation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JavaConfig {

    @Bean
    public Bike hondaBike() {
        Bike bike = new Bike();
        return bike;
    }

    @Bean
    public Bike pulsarBike() {
        Bike bike = new Bike();
        return bike;
    }
}
