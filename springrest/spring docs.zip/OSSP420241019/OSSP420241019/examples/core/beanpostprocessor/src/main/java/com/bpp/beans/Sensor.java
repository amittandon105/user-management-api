package com.bpp.beans;

import org.springframework.stereotype.Component;

@Component
public class Sensor {
    public Sensor() {
        System.out.println("Sensor()");
    }
}
