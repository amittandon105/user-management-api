package com.bpp.test;

import com.bpp.beans.Processor;
import com.bpp.helper.ObjectWatcher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class BPPTest {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new
                AnnotationConfigApplicationContext("com.bpp.beans", "com.bpp.postprocessors");

        System.out.println("no of bean instances : "+ ObjectWatcher.get());


        applicationContext.getBean(Processor.class);
        applicationContext.getBean(Processor.class);


        System.out.println("after processor, no of bean instances : "+ ObjectWatcher.get());

    }
}
