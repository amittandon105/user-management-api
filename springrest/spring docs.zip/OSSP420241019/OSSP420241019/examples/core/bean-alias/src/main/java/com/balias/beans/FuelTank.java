package com.balias.beans;

import lombok.Data;

// sourcecode
@Data
public class FuelTank {
    private int id;
    private String fuelType;
    private int capacity;

}
