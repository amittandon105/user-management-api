package com.bscopes.test;

import com.bscopes.beans.Game;
import com.bscopes.config.ScopeJavaConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class BeanScopeTest {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(ScopeJavaConfig.class);
        Game chess1 = applicationContext.getBean("chess", Game.class);
        Game chess2 = applicationContext.getBean("chess", Game.class);
        System.out.println("chess1 == chess2 ? : " + (chess1 == chess2));



        Game carom1 = applicationContext.getBean("caroms", Game.class);
        Game carom2 = applicationContext.getBean("caroms", Game.class);

        System.out.println("carom1 == carom2 ? : " + (carom1 == carom2));
    }
}
